from weasyprint import HTML
import os
# pip3 install weasyprint
# sudo apt-get install libjpeg-dev
# pip install --no-cache-dir -I pillow
path = os.getcwd()
html_path = f"{path}/description.html"
pdf_path = f"{path}/pdf_output.pdf"
Desc = """<p><iframe src="https://www.youtube.com/embed/-grLLLTza6k" frameborder="0" allowfullscreen=""></iframe></p><p><img src="https://images-na.ssl-images-amazon.com/images/I/71Zxjh0AdpL.png" style="width:100%;max-width:450px;clear:both;"></p><p></p><h2>10 Undeniable Reasons People Hate cheats</h2><p></p><p><a href="http://google.com">google</a>If you are questioning concerning utilizing a video game rip off to bump your online, computer system or computer game playing there are great deals of resources available to you. When you are very first beginning to play a game, particularly an on the internet game, you may be annoyed by your lack of skills as well as experience. You could be matched against a lot more seasoned players that benefit from you lack of expertise and abilities to beat you. A video game cheat program could also out the playing field. On the net you can download and install video game cheat software which will certainly offer you the rip off codes and other information that you will have to make you competitive with the most effective gamers.</p><p>It takes a great deal of time and patience to learn most of the on-line video games and also computer game on the market today. The majority of people do not have the time or persistence to do that, but they enjoy playing. When you play on the internet you will certainly be matched versus gamers that have accessibility to the video game cheat codes and software application currently. Give yourself that advantage by obtaining the codes and also software program on your own.</p><p>It is very easy to find a rip off program for nearly any game. You merely key in "game cheat" on your online search engine and "voila" an entire list of websites will turn up. Numerous of these websites supply cost-free trials of the software program so that you could attempt it out before you acquire it. Individuals you are betting will not have any indicator that you are making use of game rip off software application. Not just do these on the internet business supply game cheat codes for online video games but additionally games for systems like PS 2, X-Box, and the Video game Cube. The lists as well as codes are regularly being updated as brand-new video games and variations of video games appear.</p><p>A great deal of the on-line game cheat software program is interactive. You simply put it on before you start to play and also it will certainly tell you concerning upcoming chances as well as challenges as well as evaluating your challenger's relocate to tell you how to counter them. You could discover covert treasures, powers, as well as residential or commercial properties. If you like you can even most likely to various cheat code websites to try various software to understand which one you like the most effective.</p><p>No person prefers to lose. It is simply a video game, yet winning is still the things. Make on your own equivalent to your opponents and make the most of all the devices that are offered to you. As you improve you can count on them much less as well as on your own skills a lot more. It will get you going.<a href="http://yahoo.com">yahoo</a></p><p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13007070.354009148!2d-104.65387033028972!3d37.25828124582162!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2sUnited+States!5e0!3m2!1sen!2sus!4v1509017967634" frameborder="0" allowfullscreen=""></iframe></p>"""
html_file = open(html_path, "w")
html_file.write(Desc)
html_file.close()
path = os.getcwd()

HTML(html_path).write_pdf(pdf_path)
os.remove(html_path)
if os.path.isfile(pdf_path):
    print("HTML to PDF converted successfully")

# sudo apt-get install pandoc
# sudo apt-get install texlive-latex-base
# sudo apt-get install texlive-latex-recommended (optional)
# sudo apt-get install texlive-latex-extra
# import os
# bashfile = '/home/ammulu9495/Desktop/docall.sh'
# # os.system(f'sudo {bashfile}')
# os.system(bashfile)
# import os
# import stat
# path = os.getcwd()
# html_path = f"{path}/description.html"
# doc_path = f"{path}/doc_output.docx"
# bashfile =f"{path}/convertdocx.sh"
# Desc = """<p><iframe src="https://www.youtube.com/embed/-grLLLTza6k" frameborder="0" allowfullscreen=""></iframe></p><p><img src="https://images-na.ssl-images-amazon.com/images/I/71Zxjh0AdpL.png" style="width:100%;max-width:450px;clear:both;"></p><p></p><h2>10 Undeniable Reasons People Hate cheats</h2><p></p><p><a href="http://google.com">google</a>If you are questioning concerning utilizing a video game rip off to bump your online, computer system or computer game playing there are great deals of resources available to you. When you are very first beginning to play a game, particularly an on the internet game, you may be annoyed by your lack of skills as well as experience. You could be matched against a lot more seasoned players that benefit from you lack of expertise and abilities to beat you. A video game cheat program could also out the playing field. On the net you can download and install video game cheat software which will certainly offer you the rip off codes and other information that you will have to make you competitive with the most effective gamers.</p><p>It takes a great deal of time and patience to learn most of the on-line video games and also computer game on the market today. The majority of people do not have the time or persistence to do that, but they enjoy playing. When you play on the internet you will certainly be matched versus gamers that have accessibility to the video game cheat codes and software application currently. Give yourself that advantage by obtaining the codes and also software program on your own.</p><p>It is very easy to find a rip off program for nearly any game. You merely key in "game cheat" on your online search engine and "voila" an entire list of websites will turn up. Numerous of these websites supply cost-free trials of the software program so that you could attempt it out before you acquire it. Individuals you are betting will not have any indicator that you are making use of game rip off software application. Not just do these on the internet business supply game cheat codes for online video games but additionally games for systems like PS 2, X-Box, and the Video game Cube. The lists as well as codes are regularly being updated as brand-new video games and variations of video games appear.</p><p>A great deal of the on-line game cheat software program is interactive. You simply put it on before you start to play and also it will certainly tell you concerning upcoming chances as well as challenges as well as evaluating your challenger's relocate to tell you how to counter them. You could discover covert treasures, powers, as well as residential or commercial properties. If you like you can even most likely to various cheat code websites to try various software to understand which one you like the most effective.</p><p>No person prefers to lose. It is simply a video game, yet winning is still the things. Make on your own equivalent to your opponents and make the most of all the devices that are offered to you. As you improve you can count on them much less as well as on your own skills a lot more. It will get you going.<a href="http://yahoo.com">yahoo</a></p><p><iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d13007070.354009148!2d-104.65387033028972!3d37.25828124582162!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x54eab584e432360b%3A0x1c3bb99243deb742!2sUnited+States!5e0!3m2!1sen!2sus!4v1509017967634" frameborder="0" allowfullscreen=""></iframe></p>"""
# html_file = open(html_path, "w")
# html_file.write(Desc)
# html_file.close()
# bash_content = f"pandoc -o {doc_path} {html_path}"
# bash_file = open(bashfile, "w")
# bash_file.write(bash_content)
# bash_file.close()
# os.system(f'sudo chmod -R 755 {path}')
# os.system(bashfile)
# if os.path.isfile(doc_path):
#     print("HTML to Docx converted successfully")
# os.remove(html_path)
# os.remove(bashfile)

